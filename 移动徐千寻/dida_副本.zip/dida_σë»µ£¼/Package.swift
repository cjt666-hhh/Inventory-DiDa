//
//  Package.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/17.
//
import PackageDescription

let package = Package(
    name: "YourProject",
    dependencies: [
        .package(url: "https://github.com/exyte/PopupView.git", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "YourProject",
            dependencies: ["PopupView"]
        )
    ]
)



