//
//  loginModel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/26.
//

import Foundation
struct customModel:Codable{
    
    init() {
        self.name = ""
        self.password = ""
        self.id = 0
        self.username = ""
        self.createTime = ""
        self.gender = 1
        self.image = ""
        self.updateTime = ""
    }
    
    var createTime: String
    var gender: Int
    var id: Int
    var image: String
    var name: String
    var password: String
    var updateTime: String
    var username: String
           
    
    
    
}
