//
//  practiceView.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/27.
//

import SwiftUI

struct practiceView: View {
    @State private var isExpanded = true
    @ObservedObject var textlist: textViewMode
    var body: some View {
        VStack{
            Spacer()
        ScrollView {
            VStack {
                
                ForEach(textlist.textset, id: \.self) { element in
                    DisclosureGroup(
                        isExpanded: $isExpanded,
                        content: {
                            ForEach(element.content,id: \.self){ text in
                                HStack{
                                    Text(text)
                                    Spacer()
                                }
                            }
                        },
                        label: {
                            HStack{
                                Image(systemName: "plus")
                                Text(element.label)
                                
                            }
                        }
                    )
                    .frame(width: 300,height: isExpanded ? 100 : 50)
                    .background(Color.yellow) // 列表的背景颜色
                }
                
            }
            
        }
        .edgesIgnoringSafeArea(.all)
    }
}
}



#Preview {
    practiceView(textlist: game)
}
