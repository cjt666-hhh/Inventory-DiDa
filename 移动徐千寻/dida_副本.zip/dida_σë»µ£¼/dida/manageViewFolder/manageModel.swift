//
//  manageModel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/28.
//

import Foundation

struct manageModel{
    private(set) var image: String
    private(set) var signature: String
    private(set) var name: String
    init() {
        self.name = "iMenager"
        self.image = "touXiang"
        self.signature = "你可以编辑自己的个性签名"
    }
    
    
}
