//
//  manageview.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/17.
//

import SwiftUI
import Charts

struct manageview: View {
    @ObservedObject var manager: manageViewModel
    @State var signatureText: String = ""
    @State var textBar: [textmodel.text] = allContent.textset
    var body: some View {
        NavigationStack{
            ZStack{
               
                    LinearGradient(colors: [Color("linearTop2"),Color("linearBottom2")], startPoint: .top, endPoint: .bottom)
                        .ignoresSafeArea()
                    
                    
                    
                
                
                VStack(alignment: .center){
                    Image(manager.image)
                        .resizable()
                        .frame(width: 100, height: 100, alignment: .leading)
                        .clipShape(Circle())
                    VStack(spacing: 2){
                        Text(manager.name)
                            .font(.system(size: 30,weight: .medium))
                            .kerning(0.5)
                        
                        TextField(text: $signatureText) {
                            Text("你可以在此处编辑你的个性签名")
                                .font(.system(size: 13))
                                .foregroundStyle(.gray)
                            
                            
                        }
                        .padding(.leading,105)
                    }
                    
                    
                    ZStack(alignment: .leading){
                        
                        
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 300,height: 100)
                            .foregroundStyle(.white.opacity(0.6))
                        
                        
                        VStack{
                            
                            Text("本月统计清单")
                                .font(.system(size: 15,weight: .medium))
                            
                            
                            Chart(textBar,id: \.id){
                                text in
                                BarMark(
                                x: .value("textPie",text.contents.count),
                               stacking: .normalized
                                )

                                .foregroundStyle(by: .value("textBar", text.label))
                                .cornerRadius(5)
                            }.frame(width: 270,height: 27)
                                .padding(.leading,10)
                                .chartXAxis(.hidden)
                              

                            
                            
                            
                            
                            
                            
                            
                        }
                    }.padding(.top,30)
                    
                    
                    Spacer()
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 320,height: 300)
                            .ignoresSafeArea()
                            .foregroundStyle(.white.opacity(0.6))
                        
                        VStack(alignment: .leading,spacing: 20){
                            Text("选项设置")
                                .font(.system(size: 25,weight: .medium))
                                .padding(.top,30)
                            
                            NavigationLink {
                                functionView()
                            } label: {
                                HStack(spacing: 20){
                                    Image(systemName: "square.and.pencil")
                                    
                                    Text("功能模块")
                                    Spacer()
                                    Image(systemName: "arrow.right")
                                        .padding(.trailing,20)
                                }.foregroundStyle(.black)
                            }
                            
                            
                            NavigationLink {
                                voiceView()
                            } label: {
                                HStack(spacing: 20){
                                    Image(systemName: "horn")
                                    
                                    Text("声音、提醒与通知")
                                    
                                    Image(systemName: "arrow.right")
                                        .padding(.leading,27)
                                }.foregroundStyle(.black)
                            }
                            
                            
                            NavigationLink {
                                timeManageView()
                            } label: {
                                HStack(spacing: 20){
                                    Image(systemName: "calendar")
                                    
                                    Text("日期与时间")
                                    Spacer()
                                    Image(systemName: "arrow.right")
                                        .padding(.trailing,20)
                                }.foregroundStyle(.black)
                            }
                            
                            
                            NavigationLink {
                                privateManageView()
                            } label: {
                                HStack(spacing: 20){
                                    Image(systemName: "lock")
                                        .font(.system(size: 20))
                                    
                                    Text("隐私设置")
                                    Spacer()
                                    Image(systemName: "arrow.right")
                                        .padding(.trailing,20)
                                }.foregroundStyle(.black)
                            }
                            
                            
                            
                            Spacer()
                            
                        }.frame(width: 270)
                            .padding(.top,50)
                        
                    }
                    
                }.padding(.top,40)
            }
        }
    }
}
var manage = manageViewModel()
#Preview {
    manageview(manager: manage)
}
