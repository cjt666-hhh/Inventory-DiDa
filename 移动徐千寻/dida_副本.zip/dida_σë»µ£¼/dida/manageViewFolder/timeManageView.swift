//
//  timeManageView.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/28.
//

import SwiftUI

struct timeManageView: View {
    
    var body: some View {
        VStack(spacing: 50){
            Text("日期与时间")
                .font(.system(size: 20,weight: .regular))
            VStack(spacing: 20){
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 320,height: 40)
                        .foregroundStyle(.gray.opacity(0.2))
                    HStack{
                        Text("时间格式")
                        Spacer()
                        Text("跟随系统")
                            .font(.system(size: 15))
                            .foregroundStyle(.gray)
                        
                    }.frame(width: 300)
                }
                VStack(spacing: 0){
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 320,height: 120)
                            .foregroundStyle(.gray.opacity(0.2))
                        VStack(spacing: 15){
                            HStack{
                                Text("显示农历")
                                Spacer()
                                Text("已设置")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.gray)
                                
                            }.frame(width: 300)
                            
                            
                            
                            HStack{
                                Text("显示周数")
                                Spacer()
                                Text("已设置")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.gray)
                                
                            }.frame(width: 300)
                            
                            HStack{
                                Text("显示阳历")
                                Spacer()
                                Text("已设置")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.gray)
                                
                            }.frame(width: 300)
                        }
                    }
                }
            }
        Spacer()
        }.padding(.top,20)
    }
}

#Preview {
    timeManageView()
}
