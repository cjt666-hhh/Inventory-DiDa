//
//  privateManageView.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/28.
//

import SwiftUI

struct privateManageView: View {
    @State var isLogOut: Bool = false
    var body: some View {
        NavigationStack{
            VStack{
                VStack(spacing: 50){
                    Text("隐私设置")
                        .font(.system(size: 25,weight: .medium))
                    VStack(spacing: 15){
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .frame(width: 320,height: 40)
                                .foregroundStyle(.gray.opacity(0.2))
                            HStack{
                                Text("手机号")
                                Spacer()
                                Text("已设置")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.gray)
                                
                            }.frame(width: 300)
                            
                            
                        }
                        
                        
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .frame(width: 320,height: 40)
                                .foregroundStyle(.gray.opacity(0.2))
                            HStack{
                                Text("账号密码")
                                Spacer()
                                Text("已设置")
                                    .font(.system(size: 15))
                                    .foregroundStyle(.gray)
                                
                            }.frame(width: 300)
                        }
                    }
                }.padding(.top,20)
                Spacer()
                
                
                Button(action: {
                    
                }, label: {
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 0)
                            .frame(width: 320,height: 40)
                            .foregroundStyle(.gray.opacity(0.2))
                        Text("切换账号")
                    }
                })
                
                
                Button(action: {
//                    DispatchQueue.main.async {
                        UserDefaults.standard.setValue("用户名或密码错误", forKey: "move")
                        UserDefaults.standard.synchronize()
//                    }
//                   
                    isLogOut.toggle()
                }, label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 0)
                            .frame(width: 320,height: 40)
                            .foregroundStyle(.gray.opacity(0.2))
                        Text("退出登录")
                            .foregroundStyle(.red)
                    }
                }).navigationDestination(isPresented: $isLogOut) {
                    loginview(customer: userViewMode)
                }
                
                
            }
        }
    }
}

#Preview {
    privateManageView()
}
