//
//  manageViewModel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/28.
//

import SwiftUI

class manageViewModel:ObservableObject{
    @Published var manage: manageModel = manageModel()
    var image: String {
        manage.image
    }
    var signature: String {
        manage.signature
    }
    var name: String {
        manage.name
    }
}
