//
//  functionView.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/28.
//

import SwiftUI

struct functionView: View {
    var body: some View {
        NavigationStack{
            VStack(spacing: 25){
                Text("功能模块")
                    .font(.system(size: 25,weight: .medium))
                    .padding(.bottom,30)
                
                HStack(spacing: 25){
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 160,height: 160)
                            .foregroundStyle(.gray.opacity(0.2))
                        
                        VStack{
                            HStack{
                                Image(systemName: "checkmark.circle")
                                    .font(.system(size: 35,weight: .light))
                                
                                Text("待办事项")
                                    .font(.system(size: 23,weight: .medium))
                            }.padding(.bottom,5)
                            VStack(alignment: .leading){
                                Text("用待办事项和清单")
                                Text("管理工作、学习和")
                                Text("生活")
                                
                            }.foregroundStyle(.gray.opacity(0.9))
                        }
                        
                    }
                    
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 160,height: 160)
                            .foregroundStyle(.gray.opacity(0.2))
                        
                        VStack{
                            HStack{
                                Image(systemName: "calendar")
                                    .font(.system(size: 35,weight: .light))
                                
                                Text("日历")
                                    .font(.system(size: 23,weight: .medium))
                                
                            }
                            .padding(.bottom,5)
                            VStack(alignment: .leading){
                                Text("在日历视图中规划")
                                Text("任务，纵观全局并")
                                Text("掌握大方向。")
                                
                            }.foregroundStyle(.gray.opacity(0.9))
                        }
                        
                        
                        
                    }
                    
                }
                
                HStack(spacing: 25){
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 160,height: 160)
                            .foregroundStyle(.gray.opacity(0.2))
                        
                        VStack{
                            HStack{
                                Image(systemName: "chart.bar.xaxis")
                                    .font(.system(size: 35,weight: .light))
                                
                                Text("统计清单")
                                    .font(.system(size: 23,weight: .medium))
                            }.padding(.bottom,5)
                            VStack(alignment: .leading){
                                Text("统计任务类型、数")
                                Text("量，一目了然自我")
                                Text("时间分配。")
                                
                            }.foregroundStyle(.gray.opacity(0.9))
                        }
                        
                    }
                    
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 160,height: 160)
                            .foregroundStyle(.gray.opacity(0.2))
                        
                        VStack{
                            HStack{
                                Image(systemName: "command")
                                    .font(.system(size: 35,weight: .light))
                                
                                Text("设置")
                                    .font(.system(size: 23,weight: .medium))
                                
                            }
                            .padding(.bottom,5)
                            VStack(alignment: .leading){
                                Text("查看和修改设置项")
                                Text("目。")
                               
                                
                                
                            }.foregroundStyle(.gray.opacity(0.9))
                        }.padding(.bottom,24)
                        
                        
                        
                    }
                    
                }
                
                
                
                
            }
            
            Spacer()
            
            
            
            
            
            
            
        }
    }
}

#Preview {
    functionView()
}
