////
////  speechIput.swift
////  dida
////
////  Created by 徐千寻 on 2023/12/17.
////
//
//import SwiftUI
//import Speech
//
//struct speechInput: View {
//    @State private var recognizedText: String = ""
//    @State private var isRecording: Bool = false
//    
//    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
//    private let audioEngine = AVAudioEngine()
//    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
//    private var recognitionTask: SFSpeechRecognitionTask?
//    
//    var body: some View {
//        VStack {
//            Text(recognizedText)
//                .font(.largeTitle)
//                .padding()
//            
//            Button(action: {
//                if isRecording {
//                    stopRecording()
//                } else {
//                    var mutableSelf = self
//                    DispatchQueue.main.async{
//                    mutableSelf.startRecording()
//                    }
//                }
//            }) {
//                Text(isRecording ? "Stop Recording" : "Start Recording")
//                    .font(.title)
//                    .padding()
//                    .background(Color.blue)
//                    .foregroundColor(.white)
//                    .cornerRadius(10)
//            }
//        }
//        .onAppear {
//            requestSpeechAuthorization()
//        }
//    }
//    
//    private func requestSpeechAuthorization() {
//        SFSpeechRecognizer.requestAuthorization { authStatus in
//            DispatchQueue.main.async {
//                switch authStatus {
//                case .authorized:
//                    print("授权成功")
//                case .denied:
//                    print("用户拒绝了语音识别授权")
//                case .restricted:
//                    print("语音识别受限")
//                case .notDetermined:
//                    print("语音识别授权未确定")
//                @unknown default:
//                    fatalError("未知状态")
//                }
//            }
//        }
//    }
//    
//    private mutating func startRecording() {
//        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
//            return
//        }
//        
//        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
//        
//        let audioSession = AVAudioSession.sharedInstance()
//        do {
//            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
//            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
//            
//            let inputNode = audioEngine.inputNode
//            guard let recognitionRequest = recognitionRequest else {
//                fatalError("不能创建 SFSpeechAudioBufferRecognitionRequest 对象")
//            }
//            
//            recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) 
//            {
//               [self]
//                result, error in
//               
//                var isFinal = false
//                
//                if let result = result {
//                    recognizedText = result.bestTranscription.formattedString
//                    isFinal = result.isFinal
//                }
//                
//                if error != nil || isFinal {
//                    stopRecording()
//                }
//            }
//            
//            let recordingFormat = inputNode.outputFormat(forBus: 0)
//            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
//                recognitionRequest.append(buffer)
//            }
//            
//            audioEngine.prepare()
//            try audioEngine.start()
//            
//            isRecording = true
//        } catch {
//            print("启动录音引擎时出现错误：\(error)")
//        }
//    }
//    
//    private func stopRecording() {
//        audioEngine.stop()
//        recognitionRequest?.endAudio()
//        recognitionTask?.cancel()
//        
//        isRecording = false
//    }
//}
//
//
//
//#Preview {
//    speechInput()
//}




import SwiftUI
import Speech
import AVFoundation

struct speechInput: View {
    @State private var textInput: String = ""
    @State private var isRecording: Bool = false
    @State private var audioEngine: AVAudioEngine? = AVAudioEngine()
    @State private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    @State private var recognitionTask: SFSpeechRecognitionTask?
    let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))

    var body: some View {
        VStack {
            TextField("请输入文本", text: $textInput)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button(action: {
                self.startStopRecording()
            }, label: {
                Text(isRecording ? "停止录音" : "开始录音")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            })
        }
    }

    func startStopRecording() {
        if isRecording {
            stopRecording()
        } else {
            requestSpeechAuthorization()
        }
    }

    func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            DispatchQueue.main.async {
                if authStatus == .authorized {
                    self.startRecording()
                } else {
                    // 处理授权失败的情况
                }
            }
        }
    }

    func startRecording() {
        guard let recognizer = speechRecognizer else {
            // 处理语音识别器不可用的情况
            return
        }

        recognitionTask?.cancel()
        self.recognitionTask = nil

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()

        guard let recognitionRequest = recognitionRequest else {
            // 处理语音识别请求创建失败的情况
            return
        }

        let inputNode = audioEngine?.inputNode
        let recordingFormat = inputNode?.outputFormat(forBus: 0)
        inputNode?.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, _) in
            recognitionRequest.append(buffer)
        }

        audioEngine?.prepare()
        do {
            try audioEngine?.start()
        } catch {
            // 处理启动失败的情况
            return
        }

        recognitionTask = recognizer.recognitionTask(with: recognitionRequest) { result, error in
            if let result = result {
                let recognizedText = result.bestTranscription.formattedString
                DispatchQueue.main.async {
                    self.textInput = recognizedText
                }
            } else if error != nil {
                print("has an error!")
            }
        }

        isRecording = true
    }

    func stopRecording() {
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0)

        recognitionRequest?.endAudio()
        recognitionRequest = nil

        recognitionTask?.cancel()
        recognitionTask = nil

        isRecording = false
    }
}
#Preview {
    speechInput()
}
