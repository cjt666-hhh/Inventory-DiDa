//
//  dateview.swift
//
//
//  Created by 徐千寻 on 2023/11/17.
//

import SwiftUI



struct dateview: View {
    @ObservedObject var dateTextList: textViewMode
    @State var selectedDate: Date = Date()
    @State var boolArray = [Bool](repeating: true, count: 30)
//    @State var boolSet: [[Bool]] = [boolArray,]
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors: [Color("linearTop2"),Color("linearBottom2")], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                VStack{
                    //构建日历
                    DatePicker(selection: $selectedDate, label: {
                        
                    })
                    .datePickerStyle(GraphicalDatePickerStyle())
                    .padding()
                    Spacer()
                    VStack{
                        ZStack{
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 340)
                                .foregroundStyle(.white.opacity(0.7))
                                .shadow(radius: 3)
                            
                            VStack(alignment: .leading){
                                Text("待办事项")
                                    .font(.system(size: 25,weight: .medium))
                                    .padding()
                                
                                VStack{
                                    
            ForEach(dateTextList.textset.indices, id: \.self) {
                    index in
//               @State var boolArray = [Bool](repeating: true, count: dateTextList.textset[index].contents.count)
              ForEach(dateTextList.textset[index].contents.indices,id: \.self){ textIndex  in
                    HStack{
                            Button {
                    boolArray[textIndex].toggle()
                                }
                    label: {
                        if boolArray[textIndex] {
                            Image(systemName: "square")
                                }
                        else{
                            Image(systemName: "checkmark.square")
                                                        
                                                    }
                                                }

                                                
                            Text(dateTextList.textset[index].contents[textIndex].name)
                                                Spacer()
                                            }
                                            
                                            .padding(.leading,20)
                                        }
                                        
                                    }
                            
                                }
                                Spacer()
                             
                            }.frame(width:340)
                            
                            
                        }
                    }
                }
            }
        }
    }
}
#Preview {
    dateview(dateTextList: game)
}
