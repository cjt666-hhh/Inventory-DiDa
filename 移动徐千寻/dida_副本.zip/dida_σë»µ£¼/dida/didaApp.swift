//
//  didaApp.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/17.
//

import SwiftUI

@main
struct didaApp: App {
    var body: some Scene {
       
        WindowGroup {
            if (UserDefaults.standard.string(forKey: "move") == "success") {
                textview(textlist: allContent)
            } else {
                loginview(customer: userViewMode)
            }
   
        }
    }
}
