//
//  textview.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/18.
//

import SwiftUI
//import PopupView
var game = textViewMode()
//struct DisclosureGroupHeightKey: PreferenceKey {
//    static var defaultValue: CGFloat = 0
//    
//    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
//        value = nextValue()
//    }
//}
var allContent = textViewMode() //初始界面，所有未完成和完成的代办，除了删除的




let colorSet: [Color] = [Color("listColor1"),Color("listColor2"),Color("listColor3")]
struct textview: View {
    @ObservedObject var textlist: textViewMode
    @State var searching: String = ""
//    @State private var isExpanded = true
    @State var isPrint: Bool = true
    @State var isPlus: Bool = false
    @State var printIn: String = ""
    @State var boolArray = [Bool](repeating: true, count: 99)
    var body: some View {
        if isPrint{
            NavigationStack {
                //            if  isPlus{
                //                RoundedRectangle(cornerRadius: 15)
                //                    .frame(height: )
                //
                //
                //            }
                
                
                
               
                TabView{
                  VStack{
                        VStack{
                            HStack{
                                Spacer()
                                
                                NavigationLink {
                                    celaview()
                                } label: {
                                    Image(systemName: "list.bullet")
                                        .resizable()
                                        .frame(width: 23, height: 23)
                                }.transition(.move(edge:.leading))
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                Spacer()
                                HStack{
                                    Image(systemName: "magnifyingglass")
                                    
                                    
                                    TextField(text: $searching) {
                                        Text("搜索事项")
                                            .multilineTextAlignment(.leading)
                                            .opacity(0.8)
                                    }
                                    .frame(width: 250,height: 30)
                                }.background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .foregroundStyle(.searchcolor)
                                        .frame(width:300)
                                )
                                
                                Spacer()
                                
                            }
                            
                            
                            HStack(spacing: 15){
                                Button(action: {
                                    
                                }, label: {
                                    HStack(spacing: 3){
                                        Text("重要且紧急")
                                        Text("!!!!")
                                            .kerning(0)
                                    }.font(.system(size: 10))
                                        .background(
                                            RoundedRectangle(cornerRadius: 5.0)
                                                .stroke()
                                                .frame(width: 72,height: 20)
                                        )
                                        .foregroundStyle(.red)
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    HStack(spacing: 3){
                                        Text("重要但不紧急")
                                        Text("!!!")
                                            .kerning(0)
                                    }.font(.system(size: 10))
                                        .background(
                                            RoundedRectangle(cornerRadius: 5.0)
                                                .stroke()
                                                .frame(width: 78,height: 20)
                                        )
                                        .foregroundStyle(colorSet[1])
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    HStack(spacing: 3){
                                        Text("不重要但紧急")
                                        Text("!!")
                                            .kerning(0)
                                    }.font(.system(size: 10))
                                        .background(
                                            RoundedRectangle(cornerRadius: 5.0)
                                                .stroke()
                                                .frame(width: 75,height: 20)
                                        )
                                        .foregroundStyle(colorSet[0])
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    HStack(spacing: 3){
                                        Text("不重要不紧急")
                                        Text("!")
                                            .kerning(0)
                                    }.font(.system(size: 10))
                                        .background(
                                            RoundedRectangle(cornerRadius: 5.0)
                                                .stroke()
                                                .frame(width: 73,height: 20)
                                        )
                                        .foregroundStyle(colorSet[2])
                                })
                            }.padding()
                                .onAppear{
                                 
                                    DispatchQueue.global().async {
                                        
                                        Task{
                                            var data: [textmodel.text.content]
                                            data = await getAllContent(url: "https://mock.apifox.com/m1/3780945-0-default/tasks/getNotDeleted?apifoxApiId=135336268", jwt: "eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoi57OW55qE5b6IIiwiaWQiOjEsInVzZXJuYW1lIjoiY2p0NjY2IiwiZXhwIjo0NDkwMzczNDgxNX0.0qn_I1fonOhBRB-M9LvN55RF2SyxVu3pbStv3ZK3Hx0")
                                            
                                            
                                            DispatchQueue.main.async {
                                                for textInside in data {
                                                    var isNew: Bool = true
                                                    for index in allContent.model.textset.indices{
                                                        if (allContent.model.textset[index].label == textInside.signName){
                                                            isNew = false
                                                        }
                                                    }
                                                    if isNew {
                                                        allContent.model.textset.append(textmodel.text( label: textInside.signName,contents: [textInside], id: "1", image: "0"))
                                                    }else{
                                                        for index in allContent.model.textset.indices{
                                                            if (allContent.model.textset[index].label == textInside.signName){
                                                                allContent.model.textset[index].contents.append(textInside)
                                                            }
                                                        }
                                                    }
                                                    
                                                    isNew = true
                                                }
                                            }
                                        }
                                        
                                        
                                    }
//                                    for index in allContent.model.textset.indices {
//                                        var i: textViewMode
//                                        
//                                        i.model.textset.append(allContent.model.textset[index])
//                                   
//                                    }
//                                    
                                    
                                    
                                    
                                }
                            
                            
                            ScrollView {
                                
                                VStack(alignment: .trailing){
                                    
                                    
                                    VStack{
                                        ForEach(textlist.textset.indices, id: \.self) { index in
                                            
                                            DisclosureGroup(
                                                isExpanded: $boolArray[index],
                                                content: {
                                                    ForEach(textlist.textset[index].contents,id: \.id){ content in
                                                        HStack{
                                                            Text(content.name)
                                                            Spacer()
                                                        }
                                                        
                                                        .padding(.leading,20)
                                                        .padding(.bottom,10)
                                                    }
                                                },
                                                label: {
                                                    HStack{
                                                        Image("\(textlist.textset[index].image)")
                                                            .foregroundStyle(.blue)
                                                        
                                                        Text(textlist.textset[index].label)
                                                            .foregroundStyle(.white)
                                                            .font(.system(size: 20,weight: .regular))
                                                        
                                                    }
                                                    .padding(.leading,20)
                                                    
                                                }
                                            )
                                            .frame(width: 350)
                                            .background(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .foregroundStyle(colorSet[index % 3])
                                                
                                                
                                            ) // 列表的背景颜色
                                            
                                        }
                                        
                                    }
                                    
                                    
                                    
                                }
                                
                                .edgesIgnoringSafeArea(.all)
                                
                                
                                
                            }
                        }
                        Spacer()
                        
                        HStack{
                            Spacer()
                            Button(action: {
                                isPrint.toggle()
                            },
                                   label: {
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(width: 40,height: 40)
                                        .foregroundStyle(Color("plusColor"))
                                    Image(systemName: "square")
                                        .font(.title2)
                                        .foregroundStyle(.white)
                                        .offset(x:2,y:-2)
                                    
                                    ZStack{
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(width: 20,height: 20)
                                            .foregroundStyle(Color("plusColor"))
                                        
                                        
                                        Image(systemName: "plus.square")
                                            .frame(width:40,height:40)
                                            .font(.title2)
                                            .foregroundStyle(.white)
                                        
                                        
                                    }.offset(x:-2,y:2)
                                }
                            })
                            .padding()
                            //                            .popup(isPresented: $isPrint) {
                            //                                ZStack{
                            //                                    Color.black.opacity(0.3)
                            //                                        .ignoresSafeArea()
                            //                                    printSheetView(printIn: $printIn, isPrint: $isPrint)
                            //                                }
                            //                            } customize: {
                            //                                $0
                            //                                    .isOpaque(true)
                            //                                .type (.toast)
                            //                                .position(.bottom)
                            //                                .dragToDismiss(true)
                            //                            }
                            
                            
                        }
                        
                    }
                    .tabItem {
                        Image(systemName: "checkmark.circle")
                        
                    }
                    
                    
                    
                    dateview(dateTextList: game)
                        .tabItem {
                            Image(systemName: "calendar")                }
                    tongjiview()
                        .tabItem {
                            Image(systemName: "chart.bar.xaxis")
                            
                        }
                    
                    
                    manageview(manager: manage)
                        .tabItem {
                            Image(systemName: "command")
                        }
                }.navigationBarBackButtonHidden(true)
            }
        }else {
            
            printSheetView(printIn: $printIn, isPrint: $isPrint)
              
            
        }
        
        
        
        }

    }
    


#Preview {
    textview(textlist: allContent)
}
