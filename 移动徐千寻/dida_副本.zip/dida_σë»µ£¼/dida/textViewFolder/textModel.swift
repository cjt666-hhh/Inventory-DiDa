//
//  textmodel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/18.
//

import Foundation

let importanceArray = ["!","!!","!!!","!!!!"]

struct textmodel{
    var textset: [text]
    init() {
        textset = [text]()
        textset.append(text( label: "新人指导",contents: [text.content(id: 1, name: "sijfjaweofhoaawrgafaewfa", folderId: 1, isDelete: 0, isFinished: 0, signName: "新人指导", createTime: "", userId: userViewMode.id, importance: 1, isFinishOnTime: 0, finishTime: "")], id: "1", image: "0"))
        textset.append(text( label: "学习安排",contents: [text.content(id: 1, name: "hhha", folderId: 1, isDelete: 0, isFinished: 0, signName: "学习安排", createTime: "", userId: userViewMode.id, importance: 1, isFinishOnTime: 0, finishTime: "")], id: "1", image: "0"))
        textset.append(text( label: "工作任务",contents: [text.content(id: 1, name: "sijfjaweofhoaawrgafaewfa", folderId: 1, isDelete: 0, isFinished: 0, signName: "工作任务", createTime: "", userId: userViewMode.id, importance: 1, isFinishOnTime: 0, finishTime: "")], id: "1", image: "0"))
    }
    
    
    struct text:Identifiable{
        var label: String
        var contents: [text.content]
        var id: String
        var image: String
        struct content: Hashable,Codable{
            var id: Int
            var name: String
            var folderId: Int
            var isDelete: Int
            var isFinished: Int
            var signName: String
            var createTime: String
            var userId: Int
            var importance: Int
            var isFinishOnTime: Int
            var finishTime: String?
        
        }
    }
}

