//
//  TextViewModel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/20.
//

import SwiftUI

class textViewMode: ObservableObject{
    @Published var model: textmodel = textmodel()
//    static func createTextmodel() -> textmodel{
//        textmodel(label: "新人指导",id: "")
//    }
    var textset: [textmodel.text] {
        model.textset
    }
   
    
}
