//
//  printSheetView.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/2.
//

import SwiftUI

struct printSheetView: View {
    @Binding var printIn: String
    @Binding var isPrint: Bool
    var body: some View {
        
            ZStack{
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                
                VStack{
                    Spacer()
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(height: 500)
                            .foregroundStyle(.white)
                            .ignoresSafeArea()
                        
                        
                        VStack{
                            
                            
                            TextField(text: $printIn)
                            {
                                Text("输入你的待办事项......")
                                    .multilineTextAlignment(.leading)
                                    .font(.system(size: 15))
                                    .foregroundStyle(.black.opacity(0.3))
                            }.frame(width: 300,height: 30)
                                .background(
                                    RoundedRectangle(cornerRadius: 5)
                                        .foregroundStyle(.searchcolor)
                                        .frame(width:330,height: 35)
                                )
                            
                            
                            
                            HStack(spacing: 12){
                                Button(action: {
                                    
                                }, label: {
                                    Image(systemName: "calendar")
                                        .foregroundStyle(.black.opacity(0.5))
                                        .font(.system(size: 20))
                                    
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    Image(systemName: "exclamationmark.shield")
                                        .foregroundStyle(.black.opacity(0.5)) .font(.system(size: 20))
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    Image(systemName: "list.bullet")
                                        .foregroundStyle(.black.opacity(0.5)) .font(.system(size: 20))
                                })
                                Spacer()
                                
                                Button(action: {
                                    Task{
                                        var a = ""
                                        
                                        
                                        a = await postContent(url: "https://mock.apifox.com/m1/3780945-0-default/tasks/add", createTime: "", finishTime: "", folderId: 0, id: 0, importance: 0, isDelete: 0, isFinishOnTime: 0, isFinished: 0, name: printIn, signName: "新手指导", userId: userViewMode.id,jwt: "eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoi57OW55qE5b6IIiwiaWQiOjEsInVzZXJuYW1lIjoiY2p0NjY2IiwiZXhwIjo0NDkwMzczNDgxNX0.0qn_I1fonOhBRB-M9LvN55RF2SyxVu3pbStv3ZK3Hx0")
                                        // 
                                        if (a == "success") {
                                            isPrint.toggle()
                                        }
                                    }
                                }, label: {
                                    Image(systemName: "paperplane.fill") .font(.system(size: 20))
                                })
                                
                            }.frame(width: 330)
                                .padding(.top,5)
                            Spacer()
                        }.frame(height: 460)
                    }
                }.ignoresSafeArea()
            }
        }
        
    
}
