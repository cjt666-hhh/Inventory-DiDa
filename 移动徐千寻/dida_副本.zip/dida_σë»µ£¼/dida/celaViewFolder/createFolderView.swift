//
//  createFolderView.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/20.
//

import SwiftUI

struct createFolderView: View {
    @Binding var showingPopup: Bool
    @Binding var label: String
    var body: some View {
       
        ZStack{
            RoundedRectangle(cornerRadius: 10)
                .frame(width: 270,height: 480)
                .foregroundStyle(.white)
               
                .shadow(radius: 10)
            VStack{
                
                HStack{
                    Button(action: {
                        showingPopup.toggle()
                    }, label: {
                      Image(systemName: "xmark")
                    })
                    .padding(.leading,10)
                    
                    Spacer()
                    
                    Text("新建清单")
                    
                    Spacer()
                    
                    Button(action: {
                        Task{
                            var c: String = ""
                            c = await postFolder(url: "https://mock.apifox.com/m1/3780945-0-default/folder/add", id: 0, name: label, userId: 0, jwt: "eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoi57OW55qE5b6IIiwiaWQiOjEsInVzZXJuYW1lIjoiY2p0NjY2IiwiZXhwIjo0NDkwMzczNDgxNX0.0qn_I1fonOhBRB-M9LvN55RF2SyxVu3pbStv3ZK3Hx0")
                            if (c == "success"){
                                showingPopup.toggle()
                            }
                        }
                    }, label: {
                      Image(systemName: "checkmark")
                    }) .padding(.trailing,10)
                    
                }
            
                VStack(spacing: 16){
                    HStack(spacing: 0){
                        Image("folderName")
                            .resizable()
                            .scaledToFit()
                            .frame(width:20,height:20)
                            .foregroundStyle(Color("createFolderColor1"))
                            .padding(.trailing,10)
                        
                        
                        
                        
                        
                        TextField(text: $label, label: {
                            Text("输入清单名")
                                .fontDesign(.rounded)
                                .font(.system(size: 18,weight: .medium))
                                .kerning(2)
                                .foregroundStyle(Color("createFolderColor1"))
                        })
                        .frame(width: 210,height: 30)
                        
                    } 
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 260,height: 35)
                            .foregroundStyle(Color("createFolderColor2"))
                    )
                    .padding()
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 260,height:110)
                            .foregroundStyle(Color("createFolderColor2"))
                        
                        VStack(alignment: .leading)
                        {
                            HStack{
                                Text("颜色")
                                    .font(.system(size: 18))
                                Spacer()
                            }
                            
                            HStack{
                                
                                
                                
                            }
                            
                            
                        }.frame(width: 240)
                            .padding()
                        
                        
                    }
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: 260,height:110)
                            .foregroundStyle(Color("createFolderColor2"))
                        
                        VStack(alignment: .leading,spacing: 0){
                            HStack{
                                Text("图标")
                                    .font(.system(size: 20))
                                Spacer()
                            }
                            
                            HStack(spacing: 15){
                                Button(action: {
                                    
                                }, label: {
                                    Image("0f")
                                    
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    Image("1f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("2f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("3f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("4f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("5f")
                                })
                            }
                            
                            HStack(spacing: 15){
                                Button(action: {
                                    
                                }, label: {
                                    Image("6f")
                                    
                                })
                                
                                Button(action: {
                                    
                                }, label: {
                                    Image("7f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("8f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("9f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("10f")
                                })
                                Button(action: {
                                    
                                }, label: {
                                    Image("11f")
                                })
                            }
                            
                            
                        }.frame(width: 240)
                            .padding(.leading)
                        
                        
                        
                    }
                }
                Spacer()
            }
            .frame(width: 260,height: 450)
            
            
            
        } .offset(y:-50)
    }
}

//#Preview {
//    createFolderView()
//}
