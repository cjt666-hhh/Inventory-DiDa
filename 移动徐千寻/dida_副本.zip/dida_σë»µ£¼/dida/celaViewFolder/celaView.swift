//
//  celaview.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/17.
//

import SwiftUI
//import PopupView

struct celaview: View {
    @State var isHovered: Bool = false
    @State var isShow: Bool = false
    @State var showingPopup: Bool = true
    @State var label: String = ""
    var body: some View {
        
        if showingPopup {
            NavigationStack{
                ZStack{
                    Color("celacolor")
                        .ignoresSafeArea()
                    VStack(alignment:.leading){
                        HStack(spacing: 10){
                            Image("touXiang")
                                .resizable()
                                .frame(width: 65, height: 70, alignment: .leading)
                                .clipShape(Circle())
                                .padding(.leading,30)
                            
                            Text("Dida-user")
                                .font(.system(size: 25,weight: .semibold))
                                .foregroundStyle(.white)
                            Spacer()
                            Image(systemName: "pencil.circle")
                                .resizable()
                                .foregroundStyle(.white)
                                .frame(width: 30, height: 30, alignment: .leading)
                                .padding(.trailing,10)
                            
                        }
                        
                        ForEach(allContent.model.textset.indices,id: \.self){index in
                            
                        NavigationLink {
                        textview(textlist: allContent)
                                                    } 
                        label: {
                            
                            
                        HStack{
                    Image(systemName: "calendar")
                                                                .resizable()
                                                                .frame(width: 30,height: 30)
                                                                .foregroundStyle(.orange)
                                                                .padding(.leading,30)
                            Text("\(allContent.model.textset[index].label)")
                                                                .foregroundStyle(.white)
                                                                .font(.system(size: 20,weight: .semibold))
                            
                                                                .padding()
                                                            Spacer()
                                                        }
                                                    }
                            
                            
                        }
                        
                        
                        
                        
                        
//                        NavigationLink {
//                            textview(textlist: allContent)
//                        } label: {
//                            
//                            
//                            HStack{
//                                Image(systemName: "calendar")
//                                    .resizable()
//                                    .frame(width: 30,height: 30)
//                                    .foregroundStyle(.orange)
//                                    .padding(.leading,30)
//                                Text("今天")
//                                    .foregroundStyle(.white)
//                                    .font(.system(size: 20,weight: .semibold))
//                                
//                                    .padding()
//                                Spacer()
//                            }
//                        }
//                        
                        
                        
                        Spacer()
                        Button(action: {
                            showingPopup.toggle()
                            
                        }, label: {
                            HStack{
                                Image(systemName: "plus.app")
                                    .font(.system(size: 20,weight: .bold))
                                
                                Text("添加新的文件夹")
                                    .bold()
                                    .padding(.leading,10)
                                    .kerning(2)
                                
                                
                            }
                            .padding(30)
                            .foregroundStyle(.white)
                        })
                        //                    .popup(isPresented: $showingPopup) {
                        //                        ZStack{
                        //                            Color.black.opacity(0.5).ignoresSafeArea()
                        //
                        //                            createFolderView(showingPopup: $showingPopup, label: $label)
                        //                        }
                        //                    } customize: {
                        //                        $0.position(.center)
                        //                            .isOpaque(true)
                        //                    }
                        
                        
                        
                    }
                    
                }.navigationBarBackButtonHidden(true)
            }
        }else{
            
            ZStack{
                Color.black.opacity(0.5).ignoresSafeArea()
                
                createFolderView(showingPopup: $showingPopup, label: $label)
                
            }
        }
    }
}


#Preview {
  celaview()
}
