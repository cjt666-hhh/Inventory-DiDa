//
//  loginmodel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/18.
//

import Foundation
struct customModel{
    private(set) var customList: [customer]
    init(name: String,code: String,id: String) {
        customList = [customer]()
        customList.append(customer(name: name, code: code, id: id))
    }
    struct customer:Identifiable{
        var name: String
        var code: String
        var id: String
           
    }
    
    
}
