//
//  loginview.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/17.
//

//
//  loginview.swift
//  TestProject
//
//  Created by 徐千寻 on 2023/11/8.

import JWTDecode

import SwiftUI

let userViewMode: customerViewModel = customerViewModel()

struct loginview: View {
    @AppStorage("move") var b: String = "用户名或密码错误"
    @AppStorage("jwt") var jwtIdentify: String = userViewMode.userViewModel.username
   
    @ObservedObject var customer: customerViewModel
    @State var username: String = ""
    @State var code: String = ""
    @State var isPush: Bool = false
    @State var isLock: Bool = false
    @State var isSucceed: Bool = false
    @State var showAlert: Bool = false
    var body: some View {
        NavigationStack{
            ZStack{
//                LinearGradient(colors: [Color("lineartop"),Color("linearbottom")], startPoint: .top, endPoint: .bottom)
//                    .ignoresSafeArea()
                
                Image("denlubeij")
                    .ignoresSafeArea()
                
               
//                    Image("Vector")
//                        .padding(.leading,140)
                    
                    
                    VStack(alignment: .leading){
                        Spacer()
                        VStack(alignment: .leading,spacing: 10){
                            Text("欢迎登录")
                                .font(.system(size: 35,weight: .bold))
                            
                            Text("从此开启你的高效日程吧！")
                                .kerning(3)
                                .font(.system(size: 17,weight: .semibold))
                            
                            
                        }.offset(y: 200)
                    
                        VStack(spacing: 40){
                          Spacer()
                            HStack(spacing: 0){
                                
                                Image(systemName: "person.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width:20,height:30)
                                    .foregroundStyle(isPush ? Color("logincolor") : .gray)
                                    .padding(.horizontal,15)
                                
                                TextField(text: $username, label: {
                                    Text("请输入登录账号")
                                        .fontDesign(.rounded)
                                        .font(.system(size: 18,weight: .medium))
                                        .kerning(2)
                                        .foregroundStyle(Color("textcolor"))
                                    
                                    
                                }) .frame(width: 300,height: 30)
                                    .onTapGesture {
                                        isPush.toggle()
                                        if (isLock == true){
                                            isLock.toggle()
                                        }
                                        
                                        
                                    }
                            }.background(
                                RoundedRectangle(cornerRadius:20)
                                    .foregroundStyle(Color("fillcolor"))
                                    .frame(width: 350,height: 50)
                                    .shadow(color: Color.gray.opacity(0.3),radius: 1,y:3)
                                    .shadow(color:Color.orange.opacity(0.5),radius:4,y: 4))
                            
                            HStack(spacing: 0){
                                Image(systemName: "lock")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width:20,height:30)
                                    .foregroundStyle(isLock ? Color("logincolor") : .gray)
                                    .padding(.horizontal,15)
                                
                                
                                
                                
                                
                                TextField(text: $code, label: {
                                    Text("请输入登录密码")
                                        .fontDesign(.rounded)
                                        .font(.system(size: 18,weight: .medium))
                                        .kerning(2)
                                        .foregroundStyle(Color("textcolor"))
                                })
                                .frame(width: 300,height: 30)
                                .onTapGesture {
                                    isLock.toggle()
                                    if (isPush == true){
                                        isPush.toggle()
                                    }
                                }
                                
                            } .background(
                                RoundedRectangle(cornerRadius: 20)
                                    .frame(width: 350,height: 50)
                                    .foregroundStyle(Color("fillcolor"))
                                    .shadow(color: Color.gray.opacity(0.3),radius: 1,y:3)
                                    .shadow(color:Color.orange.opacity(0.5),radius:4,y: 4))
                            
                            VStack(spacing: 0){
                                NavigationLink {
                                    registerview()
                                } label: {
                                    Text("没有账号？注册一个吧！")
                                        .font(.system(size: 16,weight: .medium))
                                        .foregroundStyle(.gray)
                                    
                                    
                                }
                                
                                Rectangle()
                                    .frame(width:165,height: 1)
                                    .padding(.trailing,10)
                                
                            }
                            
                            
                            Button {
//                                DispatchQueue.global().async {
                                    Task{
                                        var a = ""
     
                                        
                       (b,a) = await getLoginUserData(url:"https://mock.apifox.com/m1/3780945-0-default/login/userLogin", username: username, password: code)
                                        
                                        
//                                        DispatchQueue.main.async {
                                            
                                            userViewMode.userViewModel.username = a

//                                        }
                                        
                                        if (b == "success") 
                                        {
                                            isSucceed.toggle()
                                            
                                        }
                                        
                                    }
//                                }
                                  
                            } label: {
                                Text("登录")
                                        .font(.system(size: 25))
                                        .bold()
                                        .foregroundStyle(.white)
                                        .background(
                                            RoundedRectangle(cornerRadius: 20)
                                                .frame(width: 350,height: 50)
                                                .foregroundStyle(Color("denlucolor")))
                                        .shadow(color: Color.gray.opacity(0.6),radius: 5,y:3)
                                        
                            }.navigationDestination(isPresented: $isSucceed) {
                                textview(textlist: allContent)
                            }


                       
                            
                            Spacer()
                        }
                        
                  
                        
                    }.offset(y: 160)
            }.navigationBarBackButtonHidden(true)
                
            }
                
                
//                
        

        }
    }


#Preview {
    loginview(customer: userViewMode)
}

