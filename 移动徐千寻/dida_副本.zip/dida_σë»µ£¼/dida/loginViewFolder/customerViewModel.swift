//
//  LoginViewModel.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/20.
//

import SwiftUI

class customerViewModel: ObservableObject{
    @Published  var userViewModel: customModel = customModel()
    var name: String
    {
        userViewModel.name
    }
    var code: String
    {
        userViewModel.password
    }
    var id: Int
    {
        userViewModel.id
        
    }
    var username: String
    {
        userViewModel.username
        
    }
    
    var image: String{
        userViewModel.image
        
    }
    var createTime: String{
        userViewModel.createTime
        
    }
    var updateTime: String{
        userViewModel.updateTime
        
    }
    
    var gender: Int{
        userViewModel.gender
        
    }
}
