//
//  registerview.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/17.
//

import SwiftUI

struct registerview: View { 
    @State var name: String = ""
    @State var code: String = ""
    @State var codeAgain: String = ""
    @State var isPush: Bool = false
    @State var isMove: Bool = false
    @State var isTouch: Bool = false
    @State var isSucceed: Bool = false
   
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors: [Color("lineartop"),Color.white], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                VStack(spacing: 40){
                    HStack(spacing: 6){
                        
                        Image(systemName: "person.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width:20,height:30)
                            .foregroundStyle(isPush ? .blue : .gray)
                            .padding(.horizontal,15)
                        
                        TextField(text: $name, label: {
                            Text("请设置注册账号")
                                .fontDesign(.rounded)
                                .font(.system(size: 18,weight: .medium))
                                .kerning(2)
                                .foregroundStyle(Color("textcolor"))
                            
                            
                        }) .frame(width: 300,height: 30)
                            .onTapGesture {
                                isPush.toggle()
                                if isMove{
                                    isMove.toggle()
                                }
                                if isTouch{
                                    isTouch.toggle()
                                }
                            }
                    }.background(
                        RoundedRectangle(cornerRadius:20)
                            .foregroundStyle(Color("fillcolor"))
                            .frame(width: 350,height: 50)
                            .shadow(color: Color.gray.opacity(0.3),radius: 1,y:3)
                            .shadow(color:Color.orange.opacity(0.5),radius:4,y: 4))
                    
                    
                    HStack(spacing: 6){
                        
                        Image(systemName: "lock")
                            .resizable()
                            .scaledToFit()
                            .frame(width:20,height:30)
                            .foregroundStyle(isMove ? .blue : .gray)
                            .padding(.horizontal,15)
                        
                        TextField(text: $code, label: {
                            Text("请设置登录密码")
                                .fontDesign(.rounded)
                                .font(.system(size: 18,weight: .medium))
                                .kerning(2)
                                .foregroundStyle(Color("textcolor"))
                            
                            
                        }) .frame(width: 300,height: 30)
                            .onTapGesture {
                                isMove.toggle()
                                if isPush{
                                    isPush.toggle()
                                }
                                if isTouch{
                                    isTouch.toggle()
                                }
                                
                            }
                    }.background(
                        RoundedRectangle(cornerRadius:20)
                            .foregroundStyle(Color("fillcolor"))
                            .frame(width: 350,height: 50)
                            .shadow(color: Color.gray.opacity(0.3),radius: 1,y:3)
                            .shadow(color:Color.orange.opacity(0.5),radius:4,y: 4))
                    
                    HStack(spacing: 6){
                        
                        Image(systemName: "lock")
                            .resizable()
                            .scaledToFit()
                            .frame(width:20,height:30)
                            .foregroundStyle(isTouch ? .blue : .gray)
                            .padding(.horizontal,15)
                        
                        TextField(text: $codeAgain, label: {
                            Text("请确认登录密码")
                                .fontDesign(.rounded)
                                .font(.system(size: 18,weight: .medium))
                                .kerning(2)
                                .foregroundStyle(Color("textcolor"))
                            
                            
                        }) .frame(width: 300,height: 30)
                            .onTapGesture {
                                isTouch.toggle()
                                if isPush{
                                    isPush.toggle()
                                }
                                if isMove{
                                    isMove.toggle()
                                }
                            }
                    }.background(
                        RoundedRectangle(cornerRadius:20)
                            .foregroundStyle(Color("fillcolor"))
                            .frame(width: 350,height: 50)
                            .shadow(color: Color.gray.opacity(0.3),radius: 1,y:3)
                            .shadow(color:Color.orange.opacity(0.5),radius:4,y: 4))
                    
                    
                    Button {
                        
                      Task{
                          var a: String = ""
                          a = await postRegisterUserData(url: "https://mock.apifox.com/m1/3780945-0-default/login/userRegiser", createTime: "", gender: 0, id: 0, image: "", name: "", password: code, username: name)
                          if (a == "success"){
                                                     
                              isSucceed.toggle()
                                                 }
                        }

                       
                    } label: {
                        Text("继续")
                                .font(.system(size: 25))
                                .bold()
                                .foregroundStyle(.white)
                                .background(
                                    RoundedRectangle(cornerRadius: 20)
                                        .frame(width: 350,height: 50)
                                        .foregroundStyle(Color("denlucolor")))
                                .shadow(color: Color.gray.opacity(0.6),radius: 5,y:3)
                                
                    }.navigationDestination(isPresented: $isSucceed) {
                        loginview(customer: userViewMode)
                    }

                }.toolbar{
                    ToolbarItem(placement: .topBarLeading) {
                        
                        VStack(alignment: .leading,spacing: 5){
                            Text("注册")
                                .font(.system(size: 35))
                                .fontWeight(.medium)
                                .kerning(3.0)
                            
                            Text("属于你的")
                                .font(.system(size: 35))
                                .fontWeight(.medium)
                                .kerning(3.0)
                            
                            Text("滴答清单账号")
                                .font(.system(size: 35))
                                .fontWeight(.medium)
                                .kerning(3)
                        }
                        .offset(x:10,y:100)
                        
                    }
                }
            }.navigationBarBackButtonHidden(true)
            
        }
    }
   
}

#Preview {
    registerview()
}
