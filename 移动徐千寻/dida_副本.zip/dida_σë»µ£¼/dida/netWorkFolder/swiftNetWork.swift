//
//  swiftNetWork.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/19.
//
//
//import Foundation
//#if canImport(FoundationNetworking)
//import FoundationNetworking
//#endif
//func getRequest(url: String){
//    let semaphore = DispatchSemaphore (value: 0)
//    
//    var request = URLRequest(url: URL(string: url)!,timeoutInterval: Double.infinity)
//    request.addValue("Apifox/1.0.0 (https://apifox.com)", forHTTPHeaderField: "User-Agent")
//    
//    request.httpMethod = "GET"
//    
//    let task = URLSession.shared.dataTask(with: request) { data, response, error in
//        guard let data = data else {
//            print(String(describing: error))
//            semaphore.signal()
//            return
//        }
//        print(String(data: data, encoding: .utf8)!)
//        semaphore.signal()
//    }
//    
//    task.resume()
//    semaphore.wait()
//}
