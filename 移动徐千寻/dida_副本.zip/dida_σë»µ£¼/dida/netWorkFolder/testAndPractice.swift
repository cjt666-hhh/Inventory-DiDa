//
//  testAndPractice.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/7.
//

import Foundation

//let a = 1
//if (a == 1) {
//    parseJWTCustomer(jwtToken: "eyJhbGciOiJIUzI1NiJ9.eyJwYXNzd29yZCI6IjEyMzQ1NiIsIm5hbWUiOm51bGwsImlkIjoxLCJ1c2VybmFtZSI6ImNqdDY2NiIsImV4cCI6MTcwMjAwNjc4OX0.3kamwz7ETCpeaNfWj_97VWG5aSdzoxzZ5SnpB5Px_1s", userViewMode: userViewMode)
//    print(userViewMode.userViewModel.id)
//}
