//
//  jwtDecodeFile.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/5.
//
import JWTDecode
import Foundation
//func parseJWTCustomer(jwtToken: String,userViewMode: customerViewModel) {
//   
//       
//    do {
//        let jwt = try decode(jwt: jwtToken)
//        userViewMode.userViewModel.id = jwt.claim(name: "id").string ?? ""
//        userViewMode.userViewModel.userName = jwt.claim(name: "username").string ?? ""
//        userViewMode.userViewModel.name = jwt.claim(name: "name").string ?? ""
//        userViewMode.userViewModel.code = jwt.claim(name: "code").string ?? ""
//        print(userViewMode.userViewModel.id)
//    } catch {
//        print("JWT decoding error: \(error)")
//    }
//
//    
// 
//}



