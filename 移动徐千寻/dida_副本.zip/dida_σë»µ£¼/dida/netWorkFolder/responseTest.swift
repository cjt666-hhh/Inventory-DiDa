//
//  responseTest.swift
//  dida
//
//  Created by 徐千寻 on 2023/12/5.
//

// testJwt: "eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoi57OW55qE5b6IIiwiaWQiOjEsInVzZXJuYW1lIjoiY2p0NjY2IiwiZXhwIjo0NDkwMzczNDgxNX0.0qn_I1fonOhBRB-M9LvN55RF2SyxVu3pbStv3ZK3Hx0"
// realjwt: UserDefaults.standard.string(forKey: "login")    content of this :    userViewMode.userViewModel.username(后端的jwt)
import Foundation

//注册网络请求
func postRegisterUserData(url: String,createTime: String?,gender: Int,id: Int,image: String?,name: String?,password: String,username: String) async -> String{
    
    let url = url
    var a = ""
    do {
        let response: Response<String> = try await ApiClient.request(url: url,method: .POST,params: ["createTime" : createTime,"gender" : gender,"id" : id,"image" : image,"name" : name,"password" : password,"updateTime": nil,"username": username],headers: ["":""])
        
        if let msg = response.msg{
            a = msg
        }else {
            print("don't receive")
        }
    } catch {
        print("Error: \(error)")
    }
     return a
}




//登录网络请求
func getLoginUserData(url: String,username: String,password: String)async -> (String,String){
    let url = url + "/\(username)/\(password)"
//    let url = url + "?username=\(username)&password=\(password)"
    var a = ""
    var k = ""
    do {
        let response: Response<String> = try await ApiClient.request(url: url,method: .GET,params: ["":""],headers: ["":""]) 
        if let data = response.data{
            
            k=data
        }
        
        if let msg = response.msg
        {
            a = msg
        
        }else {
            print("don't receive")
        }
    } catch {
        print("Error: \(error)")
    }
     return (a,k)
     
    
}

//拿到所有已经完成的代办
func getAllContent(url: String,jwt: String)async-> [textmodel.text.content] {
    let url = url
    var a = ""
    var data: [textmodel.text.content] = []
    do {
        let response: Response<[textmodel.text.content]> = try await ApiClient.request(url: url,method: .GET,params: ["":""],headers: ["token" : jwt])
        if let sq = response.data
        {
            data = sq
        }
       
        if let msg = response.msg
        {
            a = msg
            print(a)
        }else {
            print("don't receive")
        }
        
    } catch {
        print("Error: \(error)")
    }
    return data
}
    









////func postLoginUserData(url: String,createTime: String?,gender: Int,id: Int,image: String?,name: String?,password: String,username: String) async -> String{
//
//    let url = url
//    var a = ""
//    do {
//        let response: Response<String> = try await ApiClient.request(url: url,method: .GET,params: ["createTime" : createTime,"gender" : gender,"id" : id,"image" : image,"name" : name,"password" : password,"updateTime": nil,"username": username],headers: ["":""])
//        
//        
//        
//        
//        if let msg = response.msg{
//            a = msg
//        }else {
//            print("don't receive")
//        }
//    } catch {
//        print("Error: \(error)")
//    }
//
//    return a
//    
//}



//添加待办
func postContent(url: String,createTime: String?,finishTime: String?,folderId: Int,id: Int,importance: Int,isDelete: Int,isFinishOnTime: Int,isFinished: Int,name: String,signName: String,userId: Int,jwt: String) async -> String{
    
    let url = url
    var a = ""
    do {
        let response: Response<String> = try await ApiClient.request(url: url,method: .POST,params: ["createTime" : createTime,"finishTime" : finishTime,"folderId" : folderId,"id" : id,"importance" : importance,"isDelete" : isDelete,"isFinishOnTime": isFinishOnTime,"name": name,"signName": signName,"userId": userId],headers: ["token" : jwt])
        
        
        
        if let msg = response.msg{
            a = msg
        } else {
            print("don't receive")
        }
    } catch {
        print("Error: \(error)")
        
    }
    return a
}

//添加文件夹
func postFolder(url: String,id: Int, name: String, userId: Int,jwt: String)async -> String{
    let url = url
    var a = ""
    do {
        let response: Response<String> = try await ApiClient.request(url: url,method: .POST,params: ["id" : id,"name" : name,"userId" : userId],headers: ["token" : jwt])
        if let msg = response.msg{
            a = msg
           
        } else {
            print("don't receive")
        }
    } catch {
        print("Error: \(error)")
        
    }
    return a
        
        
        
    }
    
    
    
    
    



//func getUserData(url: String,createTime: String?,gender: Int,id: Int,image: String?,name: String?,password: String,username: String,token: String?) async -> String{
//    
//    let url = url
//    do {
//        let loginString = "\(username):\(password)"
//               guard let loginData = loginString.data(using: .utf8) else { return }
//               let base64LoginString = loginData.base64EncodedString()
//
//
//        
//        
//        
//        let response: Response<String> = try await ApiClient.request(url: url,method: .GET,params: ["createTime" : createTime,"gender" : gender,"id" : id,"image" : image,"name" : name,"password" : password,"updateTime": nil,"username": username],headers: ["Authorization": Basic base64(username : password)])
//        
//        if let users = response.data,
//           let mesg = response.message
//        {
//            parseJWTCustomer(jwtToken: users, userViewMode: userViewMode)
//            return mesg
//        } else {
//            print("No user data found.")
//        }
//    } catch {
//        print("Error: \(error)")
//    }
//    return ""
//}



