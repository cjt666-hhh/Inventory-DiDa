//
//  generalview.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/18.
//

import SwiftUI

struct generalview: View {
//    @ObservedObject var fulllist: textmode
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    generalview()
}
