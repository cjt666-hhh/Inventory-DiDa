//
//  ContentView.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/17.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            textview(textlist: game)
                .tabItem {
                    Text("1")
                }
            dateview()
                .tabItem {
                    Text("2")
                }
            manageview()
                .tabItem {
                    Text("3")
                }
        }.navigationBarBackButtonHidden(true)
    }
}

#Preview {
    ContentView()
}
