//
//  tongjiView.swift
//  dida
//
//  Created by 徐千寻 on 2023/11/26.
//

import SwiftUI
import Charts
struct tongjiview: View {
    @State var textPie: [textmodel.text] = allContent.textset
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(colors:[Color("linearTop2"),Color("linearBottom2")], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                
                VStack(spacing:50){
                    
                    
                    Text("统计清单")
                        .font(.system(size: 26,weight: .bold))
                    
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 330,height: 100)
                            .foregroundStyle(.white.opacity(0.8))
                            .shadow(color:Color.gray.opacity(0.3),radius: 5)
                        
                        
                        VStack{
                            HStack{
                                Text ("累计事项数/按时完成率")
                                    .fontWeight(.semibold)
                                    .padding(.bottom)
                                    .padding(.leading)
                                    .foregroundStyle(Color("tongjiZiColor"))
                                Spacer()
                            }
                           
                            HStack(spacing:50){
                                
                                VStack{
                                    Text("总事项数")
                                        .font(.system(size: 10,weight: .semibold)).foregroundStyle(Color("tongjiZiColor"))
                                    Text("120")
                                        .font(.system(size: 27))
                                    
                                }
                                
                                VStack{
                                    Text("日均事项数")
                                        .font(.system(size: 10,weight: .semibold)).foregroundStyle(Color("tongjiZiColor"))
                                    Text("4")
                                        .font(.system(size: 27))
                                    
                                }
                                
                                VStack{
                                    Text("按时完成率")
                                        .font(.system(size: 10,weight: .semibold)).foregroundStyle(Color("tongjiZiColor"))
                                    Text("90%")
                                        .font(.system(size: 27))
                                    
                                }
                                
                            }
                            
                            
                            
                        }.frame(width:320)
                          
                        
                    }
                    
                    
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 15)
                            .frame(width: 330,height: 350)
                            .foregroundStyle(.white.opacity(0.7))
                            
                        VStack{
                            
                            HStack{
                                Text("月度事项统计（11月）")
                                    .font(.system(size: 20,weight: .medium))
                                    .foregroundStyle(Color("tongjiZiColor"))
                                    .padding(.leading)
                                
                                Spacer()
                                
                            }
                            
                            Chart(textPie,id: \.id){
                                text in
                                SectorMark(
                                angle: .value("textPie",text.contents.count),
                                angularInset: 1.5
                                )
                                .cornerRadius(4)
                                .foregroundStyle(by: .value("textPie", text.label))
                            }.frame(height: 200)
                                .chartXAxis(.hidden)
                                    
                                }
                                
                                
                                
                            }
                            
                            
                            
                            
                            
                            
                            
                            
                        }.frame(width:320)
                        
                        
                        
                        
                    }
                    
                    
                    
                    
                    
                    
                }
                
                
            }
        }




//import SwiftUI
//
//struct tongjiView: View {
//    
//    var body: some View {
//        Text("hello world")
//        
//    }
//}
#Preview {
    tongjiview()
}
