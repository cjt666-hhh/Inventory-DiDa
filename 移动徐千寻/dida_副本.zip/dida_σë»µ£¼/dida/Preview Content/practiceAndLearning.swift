////
////  practiceAndLearning.swift
////  dida
////
////  Created by 徐千寻 on 2023/12/17.
////
//import SwiftUI
//
//struct ContentView: View {
//    @State private var isShowingPopup = false
//    
//    var body: some View {
//        VStack {
//            Button(action: {
//                isShowingPopup = true
//            }) {
//                Text("显示弹窗")
//                    .padding()
//                    .background(Color.blue)
//                    .foregroundColor(.white)
//                    .font(.headline)
//                    .cornerRadius(10)
//            }
//        }
//        .popup(isPresented: $isShowingPopup) {
//            CustomPopupView(title: "自定义弹窗", message: "这是一个自定义弹窗示例")
//        }
//    }
//}
//
//struct CustomPopupView: View {
//    var title: String
//    var message: String
//    
//    var body: some View {
//        VStack {
//            Text(title)
//                .font(.title)
//                .padding()
//            
//            Text(message)
//                .font(.body)
//                .padding()
//            
//            Button(action: {
//                // 在这里添加按键按下后的操作
//            }) {
//                Text("确定")
//                    .padding()
//                    .background(Color.blue)
//                    .foregroundColor(.white)
//                    .font(.headline)
//                    .cornerRadius(10)
//            }
//        }
//        .frame(width: 300, height: 200)
//        .background(Color.white)
//        .cornerRadius(10)
//        .shadow(radius: 10)
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
//
//// 弹窗扩展
//extension View {
//    func popup<PopupContent: View>(
//        isPresented: Binding<Bool>,
//        @ViewBuilder content: @escaping () -> PopupContent
//    ) -> some View {
//        ZStack {
//            self
//            
//            if isPresented.wrappedValue {
//                PopupOverlay(content: content, isPresented: isPresented)
//                    .transition(.opacity)
//            }
//        }
//    }
//}
//
//struct PopupOverlay<PopupContent: View>: View {
//    let content: () -> PopupContent
//    @Binding var isPresented: Bool
//    
//    var body: some View {
//        
//            VStack {
//                Spacer()
//                
//                content()
//                    .frame(width: 300, height: 200)
//                    .background(Color.white)
//                    .cornerRadius(10)
//                    .shadow(radius: 10)
//                
//                Spacer()
//                
//                Button(action: {
//                    isPresented = false
//                }) {
//                    Text("关闭")
//                        .padding()
//                        .background(Color.blue)
//                        .foregroundColor(.white)
//                        .font(.headline)
//                        .cornerRadius(10)
//                }
//                .padding(.bottom, 20)
//            }
//            .padding()
//            .background(Color.black.opacity(0.4))
//        }
//        
//    
//}
//
